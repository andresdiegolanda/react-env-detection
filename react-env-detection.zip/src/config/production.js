export default {
    apiUrl: 'https://api.yourapp.com',
    featureFlag: false,
  };
  