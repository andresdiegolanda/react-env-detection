export default {
    apiUrl: 'http://localhost:3000/api',
    featureFlag: true,
  };
  