export default {
    apiUrl: 'https://staging.yourapp.com/api',
    featureFlag: true,
  };
  